keys = dict(
consumer_key =          'BGpaGCjm9GDTIh6faQVj24TlE',
consumer_secret =       'PV18Pv7Ewp23IUsPIS3uYikq2BbPs9Hubl9sK4zm7kCgfvAEIn',
access_token =          '2800992971-Cq7Yz1LE1hNvExrXl3ghe2BJY781hhzM6fZqb2G',
access_token_secret =   'o37J0HKqEKPpfeCu9CNnXR7okW92ULCBKMHxSvxKbqzzZ',
)
