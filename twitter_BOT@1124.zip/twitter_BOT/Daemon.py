#!/bin/bash
python hola.py
